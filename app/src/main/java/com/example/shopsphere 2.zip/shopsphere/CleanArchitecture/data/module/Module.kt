package com.example.shopsphere.CleanArchitecture.data.module

import com.example.shopsphere.CleanArchitecture.data.Repository
import com.example.shopsphere.CleanArchitecture.data.local.SharedPreference
import com.example.shopsphere.CleanArchitecture.data.network.ApiServices
import com.example.shopsphere.CleanArchitecture.data.network.DirectionsApiServices
import com.example.shopsphere.CleanArchitecture.data.network.DummyApiServices
import com.example.shopsphere.CleanArchitecture.data.network.IRemoteDataSource
import com.example.shopsphere.CleanArchitecture.data.network.RemoteDataSource
import com.example.shopsphere.CleanArchitecture.domain.IRepository
import com.example.shopsphere.CleanArchitecture.domain.auth.FacebookLoginUseCase
import com.example.shopsphere.CleanArchitecture.domain.auth.GoogleLoginUseCase
import com.example.shopsphere.CleanArchitecture.domain.auth.LoginUseCase
import com.example.shopsphere.CleanArchitecture.domain.auth.RegisterUseCase
import com.example.shopsphere.CleanArchitecture.utils.Constant.Companion.BASE_URL
import com.example.shopsphere.CleanArchitecture.utils.Constant.Companion.DIRECTIONS_BASE_URL
import com.example.shopsphere.CleanArchitecture.utils.Constant.Companion.DUMMY_BASE_URL
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.Dns
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.net.Inet6Address
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
object Module {

    // FIX: Bypass the ngrok "You are about to visit..." browser interstitial page.
    // Without this header, ngrok returns a 403 HTML page instead of your API response.
    private class NgrokInterceptor : Interceptor {
        override fun intercept(chain: Interceptor.Chain): Response {
            val request = chain.request().newBuilder()
                .addHeader("ngrok-skip-browser-warning", "true")
                .build()
            return chain.proceed(request)
        }
    }

    // FIX: Retry up to 2 times on SocketTimeoutException before giving up.
    // ngrok free tier can stall on the first request of a burst — retrying usually succeeds.
    private class RetryInterceptor(private val maxRetries: Int = 2) : Interceptor {
        override fun intercept(chain: Interceptor.Chain): Response {
            var attempt = 0
            var lastException: Exception? = null
            while (attempt <= maxRetries) {
                try {
                    return chain.proceed(chain.request())
                } catch (e: java.net.SocketTimeoutException) {
                    lastException = e
                    attempt++
                } catch (e: java.io.IOException) {
                    lastException = e
                    attempt++
                }
            }
            throw lastException ?: java.io.IOException("Request failed after $maxRetries retries")
        }
    }

    @Singleton
    @Provides
    fun provideOkHttpClient(): OkHttpClient {
        val interceptor = HttpLoggingInterceptor().apply {
            this.level = HttpLoggingInterceptor.Level.BODY
        }

        return OkHttpClient.Builder().apply {
            this.dns(
                Dns { hostname ->
                    Dns.SYSTEM.lookup(hostname).sortedBy { it is Inet6Address }
                }
            )
            // FIX: Increased timeouts — ngrok free tier is slow, 20s read was too tight
            this.connectTimeout(60, TimeUnit.SECONDS)
            this.readTimeout(60, TimeUnit.SECONDS)
            this.writeTimeout(60, TimeUnit.SECONDS)

            // FIX: Add ngrok header so API calls get through without the browser warning page
            this.addInterceptor(NgrokInterceptor())
            // FIX: Auto-retry on timeout (fires before logging so retries appear in Logcat)
            this.addInterceptor(RetryInterceptor(maxRetries = 2))
            this.addInterceptor(interceptor)
        }.build()
    }

    @Singleton
    @Provides
    @Named("primaryRetrofit")
    fun provideRetrofit(client: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .baseUrl(BASE_URL)
            .build()
    }

    @Singleton
    @Provides
    @Named("dummyRetrofit")
    fun provideDummyRetrofit(client: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .baseUrl(DUMMY_BASE_URL)
            .build()
    }

    @Singleton
    @Provides
    @Named("directionsRetrofit")
    fun provideDirectionsRetrofit(client: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .baseUrl(DIRECTIONS_BASE_URL)
            .build()
    }

    @Singleton
    @Provides
    fun getApiServices(@Named("primaryRetrofit") retrofit: Retrofit): ApiServices {
        return retrofit.create(ApiServices::class.java)
    }

    @Singleton
    @Provides
    fun getDummyApiServices(@Named("dummyRetrofit") retrofit: Retrofit): DummyApiServices {
        return retrofit.create(DummyApiServices::class.java)
    }

    @Singleton
    @Provides
    fun getDirectionsApiServices(@Named("directionsRetrofit") retrofit: Retrofit): DirectionsApiServices {
        return retrofit.create(DirectionsApiServices::class.java)
    }

    @Singleton
    @Provides
    fun getRemoteDataSource(
        apiServices: ApiServices
    ): IRemoteDataSource {
        return RemoteDataSource(apiServices)
    }

    @Singleton
    @Provides
    fun getRepository(
        remoteDataSource: IRemoteDataSource,
        sharedPreferencesHelper: SharedPreference
    ): IRepository {
        return Repository(remoteDataSource, sharedPreferencesHelper)
    }

    @Provides
    @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides
    @Singleton
    fun provideFirebaseFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()

    @Provides
    fun provideLoginUseCase(repo: IRepository) = LoginUseCase(repo)

    @Provides
    fun provideRegisterUseCase(repo: IRepository) = RegisterUseCase(repo)

    @Provides
    fun provideGoogleLoginUseCase(repo: IRepository) = GoogleLoginUseCase(repo)

    @Provides
    fun provideFacebookLoginUseCase(repo: IRepository) = FacebookLoginUseCase(repo)
}