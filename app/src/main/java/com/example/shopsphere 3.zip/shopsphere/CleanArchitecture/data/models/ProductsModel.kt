package com.example.shopsphere.CleanArchitecture.data.models


data class ProductsModel(
    val products: List<ProductResult>
)

data class ProductResult(
    val category: String,
    val description: String,
    val id: Int,
    val image: String,
    val price: Double,
    val rating: Rating,
    val title: String,
    val stock: Int = 0
)

data class Rating(
    val count: Int,
    val rate: Double
)
