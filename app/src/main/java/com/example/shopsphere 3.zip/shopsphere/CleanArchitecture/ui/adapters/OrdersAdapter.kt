package com.example.shopsphere.CleanArchitecture.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.shopsphere.CleanArchitecture.ui.models.OrderHistoryItem
import com.example.shopsphere.R
import com.example.shopsphere.databinding.ItemOrderBinding
import java.util.Locale

class OrdersAdapter(
    private val onTrackClicked: (OrderHistoryItem) -> Unit,
    private val onReviewClicked: (OrderHistoryItem) -> Unit
) : ListAdapter<OrderHistoryItem, OrdersAdapter.OrderViewHolder>(DIFF) {

    private var completedMode = false

    init {
        setHasStableIds(true)
    }

    override fun getItemId(position: Int): Long = getItem(position).orderId.hashCode().toLong()

    fun submitList(items: List<OrderHistoryItem>, completedMode: Boolean) {
        this.completedMode = completedMode
        super.submitList(items)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val binding = ItemOrderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return OrderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class OrderViewHolder(private val binding: ItemOrderBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: OrderHistoryItem) {
            val context = itemView.context
            val dash = context.getString(R.string.orders_field_missing)
            binding.textOrderId.text = item.itemTitle.ifBlank {
                if (item.orderId.isBlank()) dash
                else context.getString(R.string.account_order_prefix, item.orderId)
            }
            val hasSize = item.itemSize.isNotBlank()
            val hasDate = item.date.isNotBlank()
            val subtitle = buildString {
                if (hasDate) append(item.date) else append(dash)
                if (hasSize) {
                    append("  •  ")
                    append(context.getString(R.string.orders_size_value, item.itemSize))
                }
            }
            binding.textOrderDate.isVisible = subtitle.isNotBlank()
            binding.textOrderDate.text = subtitle
            binding.textOrderTotal.text =
                item.total.ifBlank { item.itemPrice.ifBlank { dash } }

            Glide.with(binding.imageOrderProduct)
                .load(item.itemImageUrl)
                .placeholder(R.drawable.ic_order)
                .error(R.drawable.ic_order)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(binding.imageOrderProduct)

            // Row click ALWAYS opens the order details / tracking screen, regardless
            // of whether it is ongoing or completed. This matches the requirement
            // that every order in the list navigate to the details screen.
            binding.root.setOnClickListener { onTrackClicked(item) }

            if (completedMode) {
                binding.textOrderStatus.text = context.getString(R.string.orders_completed)
                binding.textOrderStatus.background =
                    ContextCompat.getDrawable(context, R.drawable.bg_order_status_completed)
                binding.textOrderStatus.setTextColor(ContextCompat.getColor(context, R.color.bright_green))

                val hasReview = item.reviewRating > 0.0
                binding.buttonOrderAction.isGone = hasReview
                binding.layoutRatingChip.isVisible = hasReview

                if (hasReview) {
                    binding.textReviewRating.text = context.getString(
                        R.string.reviews_average_value_inline,
                        item.reviewRating
                    )
                } else {
                    styleBlackButton(binding.buttonOrderAction)
                    binding.buttonOrderAction.text = context.getString(R.string.orders_leave_review)
                    binding.buttonOrderAction.setOnClickListener { onReviewClicked(item) }
                }
            } else {
                binding.layoutRatingChip.isGone = true
                binding.buttonOrderAction.isVisible = true
                styleBlackButton(binding.buttonOrderAction)
                binding.buttonOrderAction.text = context.getString(R.string.orders_track_order)
                binding.buttonOrderAction.setOnClickListener { onTrackClicked(item) }

                val step = resolveStatusStep(item)
                binding.textOrderStatus.text = ongoingStatusLabel(item)
                binding.textOrderStatus.background =
                    ContextCompat.getDrawable(context, statusChipBg(step))
                binding.textOrderStatus.setTextColor(
                    ContextCompat.getColor(context, statusChipColor(step))
                )
            }
        }

        private fun statusChipBg(step: Int): Int = when (step) {
            3 -> R.drawable.bg_order_status_completed
            2 -> R.drawable.bg_status_shipped
            1 -> R.drawable.bg_status_processing
            else -> R.drawable.bg_order_status_neutral
        }

        private fun statusChipColor(step: Int): Int = when (step) {
            3 -> R.color.bright_green
            2 -> R.color.status_blue
            1 -> R.color.status_orange
            else -> R.color._808080
        }

        private fun ongoingStatusLabel(item: OrderHistoryItem): String {
            return when (resolveStatusStep(item)) {
                3 -> itemView.context.getString(R.string.orders_completed)
                2 -> itemView.context.getString(R.string.track_status_in_transit)
                1 -> itemView.context.getString(R.string.track_status_picked)
                else -> itemView.context.getString(R.string.track_status_packing)
            }
        }

        private fun resolveStatusStep(item: OrderHistoryItem): Int {
            val normalizedStatus = item.status
                .trim()
                .lowercase(Locale.ENGLISH)
                .replace("_", " ")
                .replace("-", " ")

            val derivedStep = when {
                normalizedStatus.contains("deliver") || normalizedStatus.contains("complete") -> 3
                normalizedStatus.contains("transit") ||
                    normalizedStatus.contains("shipping") ||
                    normalizedStatus.contains("shipped") ||
                    normalizedStatus.contains("out for delivery") -> 2
                normalizedStatus.contains("pick") || normalizedStatus.contains("dispatch") -> 1
                else -> 0
            }

            return maxOf(item.statusStep.coerceIn(0, 3), derivedStep)
        }

        private fun styleBlackButton(button: com.google.android.material.button.MaterialButton) {
            button.background = ContextCompat.getDrawable(itemView.context, R.drawable.bg_black_action)
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<OrderHistoryItem>() {
            override fun areItemsTheSame(oldItem: OrderHistoryItem, newItem: OrderHistoryItem): Boolean =
                oldItem.orderId == newItem.orderId

            override fun areContentsTheSame(oldItem: OrderHistoryItem, newItem: OrderHistoryItem): Boolean =
                oldItem == newItem
        }
    }
}
