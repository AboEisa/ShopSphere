package com.example.shopsphere.CleanArchitecture.ui.views

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.shopsphere.CleanArchitecture.data.local.SharedPreference
import com.example.shopsphere.R
import com.example.shopsphere.CleanArchitecture.utils.showConfirmDialog
import com.example.shopsphere.CleanArchitecture.utils.showSuccessDialog
import com.example.shopsphere.databinding.FragmentAccountBinding
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class AccountFragment : Fragment() {

    private var _binding: FragmentAccountBinding? = null
    private val binding get() = _binding!!

    @Inject
    lateinit var firebaseAuth: FirebaseAuth

    @Inject
    lateinit var sharedPreference: SharedPreference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAccountBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bindProfileHeader()
        setupClicks()
    }

    override fun onResume() {
        super.onResume()
        bindProfileHeader()
    }

    private fun bindProfileHeader() {
        val firebaseUser = firebaseAuth.currentUser
        val storedName = sharedPreference.getProfileName()
        val storedEmail = sharedPreference.getProfileEmail()

        val name = storedName.ifBlank {
            firebaseUser?.displayName.orEmpty().ifBlank {
                getString(R.string.account_guest_user)
            }
        }
        val email = storedEmail.ifBlank {
            firebaseUser?.email.orEmpty().ifBlank {
                getString(R.string.account_signed_in_as)
            }
        }

        binding.textProfileName.text = name
        binding.textProfileEmail.text = email
        binding.textAvatarInitials.text = computeInitials(name)
    }

    private fun computeInitials(fullName: String): String {
        val parts = fullName.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (parts.isEmpty()) return "?"
        val first = parts.first().firstOrNull()?.uppercaseChar() ?: return "?"
        val second = if (parts.size > 1) parts[1].firstOrNull()?.uppercaseChar() else null
        return if (second != null) "$first$second" else first.toString()
    }

    private fun setupClicks() {
        binding.btnBack.setOnClickListener { requireActivity().onBackPressedDispatcher.onBackPressed() }
        binding.btnNotifications.setOnClickListener {
            findNavController().navigate(R.id.notificationsFragment)
        }

        binding.layoutOrders.setOnClickListener {
            findNavController().navigate(R.id.ordersFragment)
        }

        binding.layoutTrackOrder.setOnClickListener {
            findNavController().navigate(R.id.ordersFragment)
        }

        binding.layoutPaymentMethods.setOnClickListener {
            findNavController().navigate(R.id.paymentMethodsFragment)
        }

        binding.layoutAddressBook.setOnClickListener {
            findNavController().navigate(R.id.addressBookFragment)
        }

        binding.layoutDetails.setOnClickListener {
            findNavController().navigate(R.id.myDetailsFragment)
        }

        binding.layoutFaqs.setOnClickListener {
            findNavController().navigate(R.id.faqsFragment)
        }

        // Help Center row now opens the Sphere AI chatbot.
        binding.layoutHelpCenter.setOnClickListener {
            findNavController().navigate(R.id.action_accountFragment_to_chatBotFragment)
        }

        binding.layoutNotifications.setOnClickListener {
            findNavController().navigate(R.id.notificationsFragment)
        }

        binding.layoutAbout.setOnClickListener {
            showSuccessDialog(
                title = getString(R.string.account_about_title),
                message = getString(R.string.account_about_message)
            )
        }

        binding.layoutLanguage.setOnClickListener {
            showLanguageDialog()
        }

        binding.layoutLogout.setOnClickListener {
            showConfirmDialog(
                title = getString(R.string.dialog_logout_title),
                message = getString(R.string.dialog_logout_message),
                positiveText = getString(R.string.dialog_logout_title)
            ) {
                firebaseAuth.signOut()
                sharedPreference.clear()
                sharedPreference.saveIsLoggedIn(false)
                sharedPreference.clearUid()

                showSuccessDialog(
                    title = getString(R.string.dialog_logout_success_title),
                    message = getString(R.string.dialog_logout_success_message)
                ) {
                    val intent = Intent(requireContext(), MainActivity::class.java).apply {
                        putExtra(MainActivity.EXTRA_OPEN_HOME, false)
                        putExtra(MainActivity.EXTRA_OPEN_LOGIN, true)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    }
                    startActivity(intent)
                }
            }
        }
    }

    private fun showLanguageDialog() {
        val labels = arrayOf(
            getString(R.string.language_english),
            getString(R.string.language_arabic)
        )
        val tags = arrayOf("en", "ar")
        val current = sharedPreference.getLanguage()
        val initialIndex = tags.indexOf(current).let { if (it < 0) 0 else it }

        AlertDialog.Builder(requireContext())
            .setTitle(R.string.language_dialog_title)
            .setSingleChoiceItems(labels, initialIndex) { dialog, which ->
                val selectedTag = tags[which]
                sharedPreference.setLanguage(selectedTag)
                AppCompatDelegate.setApplicationLocales(
                    LocaleListCompat.forLanguageTags(selectedTag)
                )
                dialog.dismiss()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}
