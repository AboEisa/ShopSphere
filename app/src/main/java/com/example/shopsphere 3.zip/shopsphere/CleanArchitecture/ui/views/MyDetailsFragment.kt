package com.example.shopsphere.CleanArchitecture.ui.views

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.shopsphere.CleanArchitecture.data.local.SharedPreference
import com.example.shopsphere.CleanArchitecture.utils.showSuccessDialog
import com.example.shopsphere.R
import com.example.shopsphere.databinding.FragmentMyDetailsBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject

@AndroidEntryPoint
class MyDetailsFragment : Fragment() {

    private var _binding: FragmentMyDetailsBinding? = null
    private val binding get() = _binding!!

    @Inject
    lateinit var firebaseAuth: FirebaseAuth

    @Inject
    lateinit var sharedPreference: SharedPreference

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMyDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupGenderField()
        bindUserData()
        binding.btnBack.setOnClickListener { findNavController().navigateUp() }
        binding.btnNotifications.setOnClickListener {
            findNavController().navigate(R.id.notificationsFragment)
        }
        binding.buttonOpenDatePicker.setOnClickListener { openDatePicker() }
        binding.editBirthDate.setOnClickListener { openDatePicker() }
        binding.buttonSubmit.setOnClickListener {
            saveProfileChanges()
        }
    }

    private fun setupGenderField() {
        val options = listOf(
            getString(R.string.my_details_gender_male),
            getString(R.string.my_details_gender_female),
            getString(R.string.my_details_gender_other)
        )
        binding.editGender.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, options)
        )
        binding.editGender.setOnClickListener { binding.editGender.showDropDown() }
        binding.editGender.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) binding.editGender.showDropDown()
        }
    }

    private fun bindUserData() {
        val user = firebaseAuth.currentUser
        val localName = sharedPreference.getProfileName()
        val localEmail = sharedPreference.getProfileEmail()
        val localPhone = sharedPreference.getProfilePhone()
        val localBirthDate = sharedPreference.getProfileBirthDate()
        val localGender = sharedPreference.getProfileGender()

        // Prefer Firebase auth values (source of truth for login data). Fall back
        // to SharedPreference values saved by the user so edits aren't lost.
        val resolvedName = user?.displayName?.takeIf { it.isNotBlank() }
            ?: localName.ifBlank { user?.email?.substringBefore("@").orEmpty() }
        val resolvedEmail = user?.email?.takeIf { it.isNotBlank() } ?: localEmail
        val resolvedPhone = user?.phoneNumber?.takeIf { it.isNotBlank() } ?: localPhone

        binding.editFullName.setText(resolvedName)
        binding.editEmail.setText(resolvedEmail)
        binding.editPhone.setText(resolvedPhone)
        binding.editBirthDate.setText(localBirthDate)
        binding.editGender.setText(localGender, false)

        // Persist resolved values so other screens (Account header) reflect them.
        if (resolvedName.isNotBlank() || resolvedEmail.isNotBlank() || resolvedPhone.isNotBlank()) {
            sharedPreference.saveProfile(
                name = resolvedName,
                email = resolvedEmail,
                phone = resolvedPhone
            )
        }
    }

    private fun saveProfileChanges() {
        val name = binding.editFullName.text.toString().trim()
        val email = binding.editEmail.text.toString().trim()
        val phone = binding.editPhone.text.toString().trim()
        val birthDate = binding.editBirthDate.text.toString().trim()
        val gender = binding.editGender.text.toString().trim()

        if (name.isBlank()) {
            binding.editFullName.error = getString(R.string.my_details_full_name)
            return
        }
        if (email.isBlank()) {
            binding.editEmail.error = getString(R.string.my_details_email)
            return
        }
        if (birthDate.isBlank()) {
            binding.editBirthDate.error = getString(R.string.my_details_birth_date)
            return
        }
        if (gender.isBlank()) {
            binding.editGender.error = getString(R.string.my_details_gender)
            return
        }

        sharedPreference.saveProfile(name = name, email = email, phone = phone)
        sharedPreference.saveProfileExtras(birthDate = birthDate, gender = gender)

        val user = firebaseAuth.currentUser
        if (user != null && name != user.displayName) {
            val updates = UserProfileChangeRequest.Builder().setDisplayName(name).build()
            user.updateProfile(updates)
        }

        showSuccessDialog(
            title = getString(R.string.account_changes_saved),
            message = getString(R.string.account_changes_saved)
        ) {
            findNavController().navigateUp()
        }
    }

    private fun openDatePicker() {
        val formatter = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)
        val calendar = Calendar.getInstance()
        runCatching {
            formatter.parse(binding.editBirthDate.text.toString())?.let { parsedDate ->
                calendar.time = parsedDate
            }
        }

        DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                val selected = Calendar.getInstance().apply {
                    set(year, month, dayOfMonth)
                }
                binding.editBirthDate.setText(formatter.format(selected.time))
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
