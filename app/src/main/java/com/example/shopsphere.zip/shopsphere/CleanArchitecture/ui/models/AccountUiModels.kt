package com.example.shopsphere.CleanArchitecture.ui.models

data class AddressBookItem(
    val id: String,
    val title: String,
    val address: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val isDefault: Boolean = false,
    val isSelected: Boolean = false,
    // Contact phone for this delivery address (digits only, min 8)
    val phone: String = ""
)

data class PaymentMethodItem(
    val id: String,
    val brand: String,
    val holderName: String,
    val lastFour: String,
    val isDefault: Boolean = false,
    val isSelected: Boolean = false
)

data class OrderHistoryItem(
    val orderId: String,
    val date: String,
    val status: String,
    val total: String,
    val itemTitle: String = "",
    val itemSize: String = "",
    val itemImageUrl: String = "",
    val itemPrice: String = "",
    val reviewRating: Double = 0.0,
    val reviewComment: String = "",
    val address: String = "",
    val customerName: String = "",
    val phone: String = "",
    val destinationLat: Double? = null,
    val destinationLng: Double? = null,
    val currentLat: Double? = null,
    val currentLng: Double? = null,
    val statusStep: Int = 0,
    // Driver/courier name from the backend; null means not yet assigned
    val driverName: String? = null,
    // Payment status from /MyOrders (e.g. "Paid", "Pending"). Null = not provided.
    val paymentStatus: String? = null
)
